import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

class SlotMachineFrame extends JFrame {
  TilePanel panCenter;  // accessible throughout the class
	Tile one;
	Tile two;
	Tile three;
	Tile four;

	public void centerFrame(int width, int height) {
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension screenDims = tk.getScreenSize();
		int screenWidth = (int)screenDims.getWidth();
		int screenHeight = (int)screenDims.getHeight();
		int left = (screenWidth - width)/2;
		int top = (screenHeight - height)/2;
		setBounds(left,top,width,height);
	}

	public void setupLook() {

		one= new Tile();
		two= new Tile();
		three= new Tile();
		four= new Tile();



		centerFrame(750,500);
		setTitle("Vegas Baby Vegas Slot Machine ");
		Container c = getContentPane();
		c.setLayout(new BorderLayout());

		panCenter = new TilePanel();

		panCenter.tileList.add(one);
		panCenter.tileList.add(two);
		panCenter.tileList.add(three);
		panCenter.tileList.add(four);
		

		c.add(panCenter.tileList.get(0),BorderLayout.CENTER);
		JPanel panSouth = new JPanel();
		panSouth.setLayout(new FlowLayout());
		JButton btnMax = new JButton("Max");
		JButton btnMid = new JButton("Mid");
		JButton btnMin = new JButton("Min");
		JLabel lblText = new JLabel("$:");
		panSouth.add(lblText);
		JTextField txtText = new JTextField(5);
		panSouth.add(txtText);
/*
		btnMax.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panCenter.setText(txtText.getText());
				try {
					int fontSize = Integer.parseInt(txtFontSize.getText());
					panCenter.setFont(fontSize);
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null,"The font size must be an integer.");
				}
				repaint(); // repaints the entire window's contents. For example,
						//panCenter will be repainted --> paintComponent for TextPanel
						//will be automatically called.
			}
		});
*/
		panSouth.add(btnMax);
		panSouth.add(btnMid);
		panSouth.add(btnMin);
		c.add(panSouth,BorderLayout.SOUTH);
		setupMenu();
	}
	public void setupMenu() {
		JMenuBar mbar = new JMenuBar();
		JMenu mnuFile = new JMenu("File");
		JMenuItem miSave = new JMenuItem("Save");
		JMenuItem miClear = new JMenuItem("Clear");
		miClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// set the text on the panel to an empty string
				//panCenter.setText("");
				repaint();
			}
		});
		JMenuItem miExit = new JMenuItem("Exit");
		miExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mnuFile.add(miSave);
		mnuFile.add(miClear);
		mnuFile.add(miExit);

		JMenu mnuHelp = new JMenu("Help");
		JMenuItem miAbout = new JMenuItem("About");
		miAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null," Matthew Diaz ");
			}
		});
		mnuHelp.add(miAbout);
		mbar.add(mnuFile);
		mbar.add(mnuHelp);
		setJMenuBar(mbar);
	}
	public SlotMachineFrame() {
		setupLook();
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
}

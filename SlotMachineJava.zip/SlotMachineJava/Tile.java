import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Tile extends JPanel {
	private int shapeNum;
	private int shapeColor;
	private int xCoordinate;
	private int yCoordinate;
	private int tileWidth;
	private int tileHeight;

	public Tile(){
		shapeNum=0;
		shapeColor=0;
		xCoordinate=70;
		yCoordinate=70;
		tileWidth=70;
		tileHeight=70;
	}
	public Tile(int shapeNum, int shapeColor,int xCoordinate,int yCoordinate, int tileWidth, int tileHeight){
		this.shapeNum=shapeNum;
		this.shapeColor=shapeColor;
		this.xCoordinate = xCoordinate;
		this.yCoordinate = yCoordinate;
		this.tileWidth = tileWidth;
		this.tileHeight = tileHeight;
	}


	public void setRandomly(){
		Random randShapeObject = new Random();
		shapeNum=randShapeObject.nextInt(2);
		shapeColor=randShapeObject.nextInt(5);

	}

	public int getShapeType(){
		return shapeNum;
	}
	public void setShapeType(int shapeNumber){
		shapeNum=shapeNumber;
	}
	public int getShapeColor(){
		return shapeColor;
	}
	public void setShapeColor(int shapeColorInput){
		shapeColor=shapeColorInput;
	}

	public int getxCoordinate() {
		return xCoordinate;
	}
	public int getyCoordinate() {
		return yCoordinate;
	}
	public int getTileWidth() {
		return tileWidth;
	}
	public int getTileHeight() {
		return tileHeight;

	}
	public void setxCoordinate(int L) {
		xCoordinate=L;
	}

	public void setyCoordinate(int L) {
		yCoordinate=L;
	}
	public void setTileWidth(int L) {
		tileWidth=L;
	}
	public void setTileHeight(int L) {
		tileHeight=L;
	}


	@Override
	public void paintComponent(Graphics g) {
			super.paintComponent(g);

			 g.setColor(Color.ORANGE);
			if (shapeNum == 0) {
				g.fillOval(xCoordinate,yCoordinate,tileWidth,tileHeight);
			}
			else{
				g.fillRect(xCoordinate,yCoordinate,tileWidth,tileHeight);
			}
	}

	@Override
	public String toString() {
		return String.format("%d %d", shapeNum, shapeColor );
	}

}

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Random;
import java.util.ArrayList;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * Color setting, Mouselistener allows shapes to be clicked
 *
 */
public class TilePanel extends JPanel implements MouseListener {

  final int num=190;
  final int tileDemension= 150;
  int xSetup=10;
  final int ySetup=50;
  ArrayList<Tile> tileList;
  TilePanel() {
    addMouseListener(this);
    tileList= new ArrayList<Tile>(4);
  }

  public void clearTiles(){
    tileList.clear();
  }
  public ArrayList<Tile> getTiles() {
		return tileList;
	}

  public void setTiles(ArrayList<Tile> listOfTiles) {
    tileList=listOfTiles;
  }

  public void mouseEntered(MouseEvent e) {

  }
  public void mouseExited(MouseEvent e) {

  }
  public void mousePressed(MouseEvent e) {

  }
  public void mouseReleased(MouseEvent e) {

  }
  public void mouseClicked(MouseEvent e) {
    if(e.getX()<=187.50){
      tileList.get(0).setRandomly();

    }
    else if(e.getX()>187.50 && e.getX()<375){
      tileList.get(1).setRandomly();

    }
    else if(e.getX()>375 && e.getX()<562.5){
      tileList.get(2).setRandomly();

    }
    else {
      tileList.get(3).setRandomly();

    }


    repaint();
  }

  public Color colorDeterminer(int shapeColor){
    if(shapeColor==0){
      return Color.YELLOW;
    }
    else if(shapeColor==1){
      return Color.GREEN;
    }
    else if(shapeColor==2){
      return Color.ORANGE;
    }
    else if(shapeColor==3){
      return Color.RED;
    }
    else if(shapeColor==4){
      return Color.BLUE;
    }
    else {
    	return Color.ORANGE;
    }

  }
  @Override
  public void paintComponent(Graphics g) {
	    super.paintComponent(g);

	  xSetup=10;
      for(Tile tile: tileList){
       
        g.setColor(colorDeterminer(tile.getShapeColor()));

        if (tile.getShapeType() == 0) {
          g.fillOval(xSetup,ySetup,tileDemension,tileDemension);


        }
        else{
          g.fillRect(xSetup,ySetup,tileDemension,tileDemension);

        }
        xSetup=xSetup+num;
      }

	}


}

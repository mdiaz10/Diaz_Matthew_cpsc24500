import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.awt.Color;
import java.io.Serializable;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * Puts Shapes in Place as well as toggle shape 
 *
 */
public class Tile   {
	private int shapeNum;
	private int shapeColor;
	private int xCoordinate;
	//private int yCoordinate;


	public Tile(){
		shapeNum=0;
		shapeColor=0;
		//xCoordinate=70;
		//yCoordinate=70;
		


	}
	public Tile(int shapeNum, int shapeColor){
		this.shapeNum=shapeNum;
		this.shapeColor=shapeColor;
		//this.xCoordinate = xCoordinate;
		//this.yCoordinate = yCoordinate;

	}



	public void setRandomly(){
		Random randShapeObject = new Random();
		shapeNum=randShapeObject.nextInt(2);
		shapeColor=randShapeObject.nextInt(5);

	}

	public int getShapeType(){
		return shapeNum;
	}
	public void setShapeType(int shapeNumber){
		shapeNum=shapeNumber;
	}
	public int getShapeColor(){
		return shapeColor;
	}
	public void setShapeColor(int shapeColorInput){
		shapeColor=shapeColorInput;
	}

	public int getxCoordinate() {
		return xCoordinate;
	}
	// public int getyCoordinate() {
	// 	return yCoordinate;
	// }
	// public int getTileWidth() {
	// 	return tileWidth;
	// }
	// public int getTileHeight() {
	// 	return tileHeight;

//	}
	public void setxCoordinate(int L) {
		xCoordinate=L;
	}

	// public void setyCoordinate(int L) {
	// 	yCoordinate=L;
	// }
	// public void setTileWidth(int L) {
	// 	tileWidth=L;
	// }
	// public void setTileHeight(int L) {
	// 	tileHeight=L;
	// }

	public void toggleShapeType() {
    if (shapeNum == 0) {
      shapeNum = 1;
    }
    else {
      shapeNum = 0;
    }
  }
	@Override
	public String toString() {
		return String.format("%d %d", shapeNum, shapeColor );
	}


}
